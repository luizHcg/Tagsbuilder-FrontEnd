export { default as AuthenticationUser } from '../..\\components\\AuthenticationUser.vue'
export { default as BodyTagsBuilder } from '../..\\components\\BodyTagsBuilder.vue'
export { default as DbFind } from '../..\\components\\DBFind.vue'
export { default as Header } from '../..\\components\\Header.vue'
export { default as ModalOpening } from '../..\\components\\ModalOpening.vue'
export { default as TagsConstructor } from '../..\\components\\TagsConstructor.vue'
export { default as TagWatcherView } from '../..\\components\\TagWatcherView.vue'
export { default as Cod1Mold } from '../..\\components\\mold\\COD1MOLD.vue'
export { default as Cod2Mold } from '../..\\components\\mold\\COD2MOLD.vue'
export { default as Cod3Mold } from '../..\\components\\mold\\COD3MOLD.vue'
export { default as Cod4Mold } from '../..\\components\\mold\\COD4MOLD.vue'
export { default as Cod5Mold } from '../..\\components\\mold\\COD5MOLD.vue'
export { default as Cod6Mold } from '../..\\components\\mold\\COD6MOLD.vue'
export { default as Cod7Mold } from '../..\\components\\mold\\COD7MOLD.vue'
export { default as Cod1 } from '../..\\components\\tag\\COD1.vue'
export { default as Cod2 } from '../..\\components\\tag\\COD2.vue'
export { default as Cod3 } from '../..\\components\\tag\\COD3.vue'
export { default as Cod4 } from '../..\\components\\tag\\COD4.vue'
export { default as Cod5 } from '../..\\components\\tag\\COD5.vue'
export { default as Cod6 } from '../..\\components\\tag\\COD6.vue'
export { default as Cod7 } from '../..\\components\\tag\\COD7.vue'

export const LazyAuthenticationUser = import('../..\\components\\AuthenticationUser.vue' /* webpackChunkName: "components_AuthenticationUser" */).then(c => c.default || c)
export const LazyBodyTagsBuilder = import('../..\\components\\BodyTagsBuilder.vue' /* webpackChunkName: "components_BodyTagsBuilder" */).then(c => c.default || c)
export const LazyDbFind = import('../..\\components\\DBFind.vue' /* webpackChunkName: "components_DBFind" */).then(c => c.default || c)
export const LazyHeader = import('../..\\components\\Header.vue' /* webpackChunkName: "components_Header" */).then(c => c.default || c)
export const LazyModalOpening = import('../..\\components\\ModalOpening.vue' /* webpackChunkName: "components_ModalOpening" */).then(c => c.default || c)
export const LazyTagsConstructor = import('../..\\components\\TagsConstructor.vue' /* webpackChunkName: "components_TagsConstructor" */).then(c => c.default || c)
export const LazyTagWatcherView = import('../..\\components\\TagWatcherView.vue' /* webpackChunkName: "components_TagWatcherView" */).then(c => c.default || c)
export const LazyCod1Mold = import('../..\\components\\mold\\COD1MOLD.vue' /* webpackChunkName: "components_mold/COD1MOLD" */).then(c => c.default || c)
export const LazyCod2Mold = import('../..\\components\\mold\\COD2MOLD.vue' /* webpackChunkName: "components_mold/COD2MOLD" */).then(c => c.default || c)
export const LazyCod3Mold = import('../..\\components\\mold\\COD3MOLD.vue' /* webpackChunkName: "components_mold/COD3MOLD" */).then(c => c.default || c)
export const LazyCod4Mold = import('../..\\components\\mold\\COD4MOLD.vue' /* webpackChunkName: "components_mold/COD4MOLD" */).then(c => c.default || c)
export const LazyCod5Mold = import('../..\\components\\mold\\COD5MOLD.vue' /* webpackChunkName: "components_mold/COD5MOLD" */).then(c => c.default || c)
export const LazyCod6Mold = import('../..\\components\\mold\\COD6MOLD.vue' /* webpackChunkName: "components_mold/COD6MOLD" */).then(c => c.default || c)
export const LazyCod7Mold = import('../..\\components\\mold\\COD7MOLD.vue' /* webpackChunkName: "components_mold/COD7MOLD" */).then(c => c.default || c)
export const LazyCod1 = import('../..\\components\\tag\\COD1.vue' /* webpackChunkName: "components_tag/COD1" */).then(c => c.default || c)
export const LazyCod2 = import('../..\\components\\tag\\COD2.vue' /* webpackChunkName: "components_tag/COD2" */).then(c => c.default || c)
export const LazyCod3 = import('../..\\components\\tag\\COD3.vue' /* webpackChunkName: "components_tag/COD3" */).then(c => c.default || c)
export const LazyCod4 = import('../..\\components\\tag\\COD4.vue' /* webpackChunkName: "components_tag/COD4" */).then(c => c.default || c)
export const LazyCod5 = import('../..\\components\\tag\\COD5.vue' /* webpackChunkName: "components_tag/COD5" */).then(c => c.default || c)
export const LazyCod6 = import('../..\\components\\tag\\COD6.vue' /* webpackChunkName: "components_tag/COD6" */).then(c => c.default || c)
export const LazyCod7 = import('../..\\components\\tag\\COD7.vue' /* webpackChunkName: "components_tag/COD7" */).then(c => c.default || c)
