class PcProdut {
  CODPROD!: number

  DESCRICAO!: string

  UNIDADE!: string

  CODFAB!: string

  EMBALAGEM!: string

  DESCRICAO4?: string

  DESCRICAO5?: string

  DESCRICAO7?: string
}

export default PcProdut
