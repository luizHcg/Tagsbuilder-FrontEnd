import Tag from './Tag'

class PrintTag {
  tag!: Tag
  quantity = 1
}

export default PrintTag
